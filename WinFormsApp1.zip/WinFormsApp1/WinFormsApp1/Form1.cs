using System.Data;
using Microsoft.Data.SqlClient;
namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        //Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SalesDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=SalesDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataSet ds;

        void showData()
        { 
            conn.Open();
            cmd = new SqlCommand();
            cmd.CommandText = "select i.itemDesc as Description, inv.invDate as Date, inv.begInv as [Start Qty], inv.EndInv  from Items i "
                            + " inner join inventory inv on inv.itemId = i.itemID";
            cmd.Connection = conn;
            adapter = new SqlDataAdapter(cmd);
            ds = new DataSet();
            adapter.Fill(ds,"Items, Inventory");
            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();



        }
        private void Form1_Load(object sender, EventArgs e)
        {
            showData();
        }
    }
}
