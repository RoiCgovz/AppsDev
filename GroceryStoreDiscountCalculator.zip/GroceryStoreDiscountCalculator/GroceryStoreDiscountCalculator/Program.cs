﻿using System;
using System.Collections;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace GroceryStoreDiscountCalculator
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            string input;           
            while (true)
            {
                Console.WriteLine("***** WELCOME TO THE GROCERY STORE DISCOUNT CALCULATOR *****");
                Console.WriteLine("1: Purchase an Item");
                Console.WriteLine("2: Display Product");
                Console.WriteLine("3: Display Purchase Product");
                Console.WriteLine("x: Exit Progam");
                input = Console.ReadLine();
                if (input.Equals("x"))
                {
                    break;
                }
                switch (input)
                {
                    case "1":
                        break;
                    case "2":
                        break;
                    case "3":
                        break;
                    case "x":
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        break;
                }
            }
        }
        static void Purchase()
        {

        }
        static string Item_List()
        {
            ArrayList items = new ArrayList();
            
        }
    }
}